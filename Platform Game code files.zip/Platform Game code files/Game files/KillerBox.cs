using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KillerBox : MonoBehaviour
{

    public Vector3 direction;
    public float speed;
    public bool reverse = false;

    Vector3 force;

    void Start()
    {
        force = Vector3.left * speed;

        if (reverse)
        {
            Reverse();
        }
    }
    private void FixedUpdate()
    {
        Debug.DrawRay(transform.position, direction, Color.red, 0.1f, false);

        Ray ray = new Ray(transform.position, direction);
        RaycastHit hit;
        if (Physics.Raycast(ray, out hit))
        {
            
            if (hit.transform.gameObject.CompareTag("Terrain") || hit.transform.gameObject.CompareTag("Player"))
            {
                Move();
            }
            else
            {
                Reverse();
            }
        }
        else
        {
            Reverse();
        }
    }
    void Move()
    {
        transform.GetComponent<Rigidbody>().velocity = force;
    }

    void Reverse()
    {
        force = -force;
        direction.Set(-direction.x, direction.y, direction.z);
    }

}