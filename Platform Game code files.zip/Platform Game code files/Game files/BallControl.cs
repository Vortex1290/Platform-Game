using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class BallControl : MonoBehaviour
{
    [Header("Opcje Poruszania")]
    [SerializeField]
    private bool isRigidbody;
    public float maxAngularVelocity;
    public float speed;

    private GameManager gameManager;

    [SerializeField]
    private Rigidbody rb;

    // Start is called before the first frame update
    void Start()
    {
        if (isRigidbody = TryGetComponent<Rigidbody>(out rb))
        {
            rb.maxAngularVelocity = maxAngularVelocity;
        }
        gameManager = GameObject.FindGameObjectWithTag("GameController").GetComponent<GameManager>();
    }

    // Update is called once per frame
    void Update()
    {
        if (transform.position.y <= -30f)
        {
            gameManager.RestartLevel();
        }
    }
    private void FixedUpdate()
    {
        float Hdirection;
        float Vdirection;

        if (isRigidbody && (Hdirection = Input.GetAxis("Horizontal")) != 0)
        {
            rb.AddTorque(0, 0, -Hdirection * speed * Time.fixedDeltaTime);
        }
        if (isRigidbody && (Vdirection = Input.GetAxis("Vertical")) != 0)
        {
            rb.AddTorque(Vdirection * speed * Time.fixedDeltaTime, 0, 0);
        }
    }
}
