using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RedBlueKey : MonoBehaviour
{
    private GameObject finishDoor;
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            finishDoor = GameObject.FindGameObjectWithTag("Finish");
            Destroy(finishDoor);
            Destroy(gameObject);

        }
    }
}
