using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PortalTransport : MonoBehaviour
{
    private GameObject ballObject;

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            ballObject = GameObject.FindGameObjectWithTag("Player");
            ballObject.transform.position= new Vector3(-58.415f, -14.61f, 77.93f);
            
        }
    }
}
