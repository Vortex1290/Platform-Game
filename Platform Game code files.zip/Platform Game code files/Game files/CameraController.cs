using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

public class CameraController : MonoBehaviour
{
    [SerializeField]
    private float lookUp;

   
    public float lerpAmount;
    public Vector3 jumpUp;
    public float sensitivity = 1f;

    private GameObject ballObject;

    // Start is called before the first frame update
    void Start()
    {
        QualitySettings.vSyncCount= 1;
        Application.targetFrameRate = 60; 

        ballObject = GameObject.FindGameObjectWithTag("Player");
    }
    private void Update()
    {
        
    }

    void LateUpdate()
    {
        transform.position = Vector3.Lerp(transform.position, ballObject.transform.position + jumpUp, lerpAmount * Time.deltaTime);
        transform.LookAt(ballObject.transform.position);
        transform.Rotate(-lookUp, 0, 0);
    }

}
