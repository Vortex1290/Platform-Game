using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    [Header("Player Settings")]
    public GameObject Player;
    public Transform startPosition;

    [Header("Score Settings")]
    public TextMeshProUGUI pointsText;
    public int points;

    private void Awake()
    {
        //Instantiate(Player, startPosition.position, Quaternion.identity);
    }
    private void Update()
    {
        pointsText.text = "Points: " + points;
    }
    public void RestartLevel()
    {      
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);      
    }



}
