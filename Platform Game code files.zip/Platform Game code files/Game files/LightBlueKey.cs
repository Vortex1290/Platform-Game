using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LightBlueKey : MonoBehaviour
{
    private GameObject portalDoor;
     
   
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            portalDoor= GameObject.FindGameObjectWithTag("PortalDoor");
            Destroy(portalDoor);
            Destroy(gameObject);
            
        }
    }
}
