using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PortalToFinish : MonoBehaviour
{
    private GameObject ballObject;

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            ballObject = GameObject.FindGameObjectWithTag("Player");
            ballObject.transform.position = new Vector3(6.106139f, 1f, -10f);

        }
    }
}
