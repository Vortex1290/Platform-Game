using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyObject : MonoBehaviour
{
    public Color startColor;
    public Color endColor;
    public int life;

    private Material material;
    private int maxLife = 3;
    private bool isRigidbody;

    Rigidbody rb;

    // Start is called before the first frame update
    void Start()
    {
        life = Mathf.Clamp(life, 1, 3);
        material = GetComponent<MeshRenderer>().material;

        if(isRigidbody)
        {
            rb=gameObject.AddComponent<Rigidbody>();
            rb.interpolation = RigidbodyInterpolation.Interpolate;
            rb.collisionDetectionMode = CollisionDetectionMode.Continuous;
            rb.mass = 0.75f;
        }        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            life--;
            if (life > 0)
            {
                SetColor();
            }
            else
            {
                Destroy(this.gameObject);
            }
        }
    }
    void SetColor()
    {
        material.color = Color.Lerp(endColor, startColor, ((float)life-1)/((float)maxLife));
    }
    private void OnValidate()
    {
        material = GetComponent<MeshRenderer>().sharedMaterial;
        SetColor();       
    }
}
